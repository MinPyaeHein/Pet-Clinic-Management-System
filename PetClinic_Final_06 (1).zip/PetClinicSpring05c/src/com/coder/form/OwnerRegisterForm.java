package com.coder.form;

import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;

public class OwnerRegisterForm {
private OwnerForm ownerForm;
public OwnerForm getOwnerForm() {
	return ownerForm;
}

public void setOwnerForm(OwnerForm ownerForm) {
	this.ownerForm = ownerForm;
}
}
