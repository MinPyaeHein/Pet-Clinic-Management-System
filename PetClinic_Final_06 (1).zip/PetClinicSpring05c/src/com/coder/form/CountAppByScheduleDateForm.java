package com.coder.form;

public class CountAppByScheduleDateForm {
private String scheduleId;
private String date;
private String count;
public String getScheduleId() {
	return scheduleId;
}
public void setScheduleId(String scheduleId) {
	this.scheduleId = scheduleId;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getCount() {
	return count;
}
public void setCount(String count) {
	this.count = count;
}

}
