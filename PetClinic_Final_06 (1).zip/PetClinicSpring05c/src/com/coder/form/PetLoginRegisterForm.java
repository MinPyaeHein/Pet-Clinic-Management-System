package com.coder.form;

public class PetLoginRegisterForm {
private PetLoginForm petLoginForm=null;

public PetLoginForm getPetLoginForm() {
	return petLoginForm;
}

public void setPetLoginForm(PetLoginForm petLoginForm) {
	this.petLoginForm = petLoginForm;
}
}
