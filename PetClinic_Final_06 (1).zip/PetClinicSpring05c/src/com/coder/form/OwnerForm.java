package com.coder.form;

public class OwnerForm {
	private String ownerId;
	private String ownerPassword;
	private String ownerName;
	private String ownerPh;
	private String ownerEmail;
	private String ownerAdd;
	private String ownerGender;
	private String ownerAddress;
	public String getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getOwnerPh() {
		return ownerPh;
	}
	public void setOwnerPh(String ownerPh) {
		this.ownerPh = ownerPh;
	}
	public String getOwnerEmail() {
		return ownerEmail;
	}
	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}
	public String getOwnerAdd() {
		return ownerAdd;
	}
	public void setOwnerAdd(String ownerAdd) {
		this.ownerAdd = ownerAdd;
	}
	public String getOwnerGender() {
		return ownerGender;
	}
	public void setOwnerGender(String ownerGender) {
		this.ownerGender = ownerGender;
	}
	public String getOwnerAddress() {
		return ownerAddress;
	}
	public void setOwnerAddress(String ownerAddress) {
		this.ownerAddress = ownerAddress;
	}
	public String getOwnerPassword() {
		return ownerPassword;
	}
	public void setOwnerPassword(String ownerPassword) {
		this.ownerPassword = ownerPassword;
	}
	
}
