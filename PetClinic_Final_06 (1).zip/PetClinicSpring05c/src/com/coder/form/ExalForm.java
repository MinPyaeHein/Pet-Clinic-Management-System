package com.coder.form;

public class ExalForm {
private String appDate;
private String scheduleId;
private String avgWt;
private String sjfAvgWt;
public String getAppDate() {
	return appDate;
}
public void setAppDate(String appDate) {
	this.appDate = appDate;
}
public String getAvgWt() {
	return avgWt;
}
public void setAvgWt(String avgWt) {
	this.avgWt = avgWt;
}
public String getSjfAvgWt() {
	return sjfAvgWt;
}
public void setSjfAvgWt(String sjfAvgWt) {
	this.sjfAvgWt = sjfAvgWt;
}
public String getScheduleId() {
	return scheduleId;
}
public void setScheduleId(String scheduleId) {
	this.scheduleId = scheduleId;
}

}
